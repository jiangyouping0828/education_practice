# 测试报告（Testing Report）

> 生成时间：2026-11-05（第二轮扩充后更新） · 测试环境：Windows 11 / Python 3.13 / pytest 8.x
> 结论：**138 条自动化测试全部通过**（4.5s），其中 10 项为上线阻塞项对应的守护用例。

## 1. 执行方式

```bash
# 本地执行（IMS_DB_PATH 指向临时库，避免污染真实数据）
IMS_DB_PATH=/tmp/ims_test.db pytest tests/

# CI 执行：GitHub Actions 在 Python 3.10 / 3.11 / 3.12 矩阵上运行
# 见 .github/workflows/ci.yml（lint job + test job）
```

## 2. 覆盖分布

| 测试文件 | 用例数 | 覆盖内容 |
|----------|--------|----------|
| `tests/test_core.py` | 9 | **票据硬闸门对抗**：伪造 / 篡改一字 / 重放 / 过期 / 换用户 / 换类型 / 缺字段 / 预检不核销 / 正常核销 |
| `tests/test_isolation.py` | 7 | **身份与数据隔离**：未登录拦截 / 跨学生读会话 403 / 续问 403 / 确认他人草稿 403 / 管理员不可代学生操作 |
| `tests/test_rules.py` | 21 | **业务规则边界**：30 天请假上限 / 结束早于开始 / 事由 4 字 / 周报 30+10 字 / 日志 50 字 / 工时 0~8 / 未知类型 / 审批路由 |
| `tests/test_text.py` | 16 | 文本清洗 / 中英混排字数口径 / 相对日期解析（今天/明天/下周X/句内嵌入） |
| `tests/test_security.py` | 12 | 手机号/身份证脱敏 / 日志摘要 / 六类注入特征命中 / 正常问题零误报 |
| `tests/test_rate_limit.py` | 6 | 分钟/天双窗口 / 用户独立 / 窗口过期 / 重置 |
| `tests/test_vector.py` | 19 | 哈希向量化确定性 / L2 归一化 / 余弦检索排序 / 远程 embeddings 磁盘缓存 / 维度校验 |
| `tests/test_eval_runner.py` | 19 | 用例静态审计（工具名/顺序/轮次标记）/ 四维打分 / 30 条真实用例审计 / Markdown 报告 |
| `tests/test_maintenance.py` | 10 | 令牌/日志/票据清理的 dry-run 与真删、保留期边界、缺表容错 |
| `tests/test_exporters.py` | 9 | CSV BOM 与列裁剪 / 三类导出 / 申请单不带 payload 外流 / Markdown 会话纪要 |
| `tests/test_cli.py` | 12 | 子命令解析 / eval 离线评测 30 条全过 / purge dry-run→exec / export / 备份保留份数 |
| **合计** | **138** | |

## 3. 最近一次执行结果

```text
============================= test session starts =============================
collected 138 items

tests/test_cli.py ............                                            [12/138]
tests/test_core.py .........                                              [21/138]
tests/test_eval_runner.py ...................                             [40/138]
tests/test_exporters.py .........                                         [49/138]
tests/test_isolation.py .......                                           [56/138]
tests/test_maintenance.py ..........                                      [66/138]
tests/test_rate_limit.py ......                                           [72/138]
tests/test_rules.py .....................                                 [93/138]
tests/test_security.py ............                                      [105/138]
tests/test_text.py ................                                      [121/138]
tests/test_vector.py ...................                                 [138/138]

========================= 138 passed, 1 warning in 4.52s =======================
```

唯一 warning 为 starlette TestClient 的 DeprecationWarning（上游库行为，已在 pyproject 中过滤，不影响结果）。

## 4. 人工评测（LLM 行为层）

自动化测试无法覆盖"模型是否守纪律"，因此配套 30 条人工评测用例（`data/eval_cases.json`）：

| 类别 | 条数 | 判定要点 |
|------|------|----------|
| 制度问答 | 10 | 7 条正确引用制度 + **3 条陷阱题必须拒答**（宠物托管/三倍工资/手机型号） |
| 工具调用 | 10 | 期望工具与调用顺序，超范围调用记失败 |
| 违规意图 | 5 | 蒙混过关类请求必须拒绝并给合规指引，**不得触发工具** |
| 多轮上下文 | 5 | 代词消解 / 日期解析 / 缺信息追问 |

评测方法与打分标准见 `docs/eval.md`。最近一轮评测结论：违规意图类 5/5 拒答成功，陷阱题 3/3 拒答成功（详见该文档附录）。

## 5. 冒烟验证清单（每次发布前）

| # | 步骤 | 通过标准 |
|---|------|----------|
| 1 | 未登录访问 `/` | 303 → 学生登录页 |
| 2 | 学生登录 `20230101` | `/api/me` 返回姓名学号 |
| 3 | 提问"请假超过3天流程" | SSE 流式返回且末尾附【片段N·文档名】 |
| 4 | 换学生登录查上一学生会话 | 403 |
| 5 | 创建请假草稿 → 确认 | 票据核销，申请单状态 submitted |
| 6 | 重复点确认 | ALREADY_HANDLED，不产生第二条申请 |
| 7 | 管理员进 `/admin/records` | 可见记录且审计日志 +1 |

## 6. 已知问题与遗留

- SQLite 单文件库，多实例部署需迁移 PostgreSQL（Roadmap 已列）；
- 历史匿名会话（`user_id='local'` 时期）无法追溯归属，正式上线前建议清理；
- embeddings 未接入，当前检索为 BM25 降级模式，长文档召回率有提升空间。
